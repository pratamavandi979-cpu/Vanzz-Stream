package com.vanzz.stream;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override public void onCreate(Bundle b) {
    registerPlugin(VanzzPlayerPlugin.class);
    super.onCreate(b);
  }
  @Override public void onStart() {
    super.onStart();
    try { getBridge().getWebView().getSettings().setMediaPlaybackRequiresUserGesture(false); } catch (Exception e) {}
  }
}
