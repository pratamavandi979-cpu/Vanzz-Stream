package com.vanzz.stream;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.app.NotificationCompat;
import java.net.HttpURLConnection;
import java.net.URL;

public class MediaService extends Service {
  static MediaService inst;
  static boolean bg = false;

  private MediaSessionCompat ms;
  private NotificationManager nm;
  private final Handler h = new Handler(Looper.getMainLooper());
  private String title = "", artist = "", lyric = "", artUrl = "";
  private Bitmap art;
  private boolean playing, fg;
  private long pos, dur, stamp;
  private WindowManager wm;
  private LinearLayout pill;
  private TextView pt, pl;

  @Override public void onCreate() {
    super.onCreate();
    inst = this;
    nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) {
      nm.createNotificationChannel(new NotificationChannel("vz", "Pemutar musik", NotificationManager.IMPORTANCE_LOW));
    }
    ms = new MediaSessionCompat(this, "VanzzStream");
    ms.setCallback(new MediaSessionCompat.Callback() {
      @Override public void onPlay() { VanzzPlayerPlugin.emit("play", 0); }
      @Override public void onPause() { VanzzPlayerPlugin.emit("pause", 0); }
      @Override public void onSkipToNext() { VanzzPlayerPlugin.emit("next", 0); }
      @Override public void onSkipToPrevious() { VanzzPlayerPlugin.emit("prev", 0); }
      @Override public void onSeekTo(long p) { VanzzPlayerPlugin.emit("seek", p / 1000.0); }
    });
    ms.setActive(true);
  }

  @Override public int onStartCommand(Intent i, int f, int id) {
    if (i != null && i.getAction() != null) {
      VanzzPlayerPlugin.emit(i.getAction(), 0);
    } else if (i != null) {
      apply(i.getStringExtra("t") == null ? "" : i.getStringExtra("t"),
            i.getStringExtra("a") == null ? "" : i.getStringExtra("a"),
            i.getStringExtra("u") == null ? "" : i.getStringExtra("u"),
            i.getBooleanExtra("p", false), i.getLongExtra("pos", 0), i.getLongExtra("dur", 0));
    }
    if (!fg) h.post(this::render);
    return START_NOT_STICKY;
  }

  void apply(final String t, final String a, final String u, final boolean p, final long ps, final long d) {
    h.post(() -> {
      title = t; artist = a; playing = p; pos = ps; dur = d; stamp = SystemClock.elapsedRealtime();
      if (!u.equals(artUrl)) { artUrl = u; art = null; lyric = ""; loadArt(u); }
      render();
    });
  }

  void setLyric(final String l) { h.post(() -> { lyric = l == null ? "" : l; render(); }); }
  void refresh() { h.post(this::pill); }

  void kill() {
    h.post(() -> {
      removePill();
      stopForeground(true);
      fg = false;
      stopSelf();
    });
  }

  private void loadArt(final String u) {
    if (u.isEmpty()) return;
    new Thread(() -> {
      try {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(6000);
        c.setReadTimeout(8000);
        Bitmap b = BitmapFactory.decodeStream(c.getInputStream());
        if (b != null && u.equals(artUrl)) { art = b; h.post(this::render); }
      } catch (Exception e) { }
    }).start();
  }

  private PendingIntent act(String a, int rc) {
    Intent i = new Intent(this, MediaService.class).setAction(a);
    return PendingIntent.getService(this, rc, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
  }

  private Intent launch() {
    Intent li = getPackageManager().getLaunchIntentForPackage(getPackageName());
    if (li != null) li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    return li;
  }

  private void render() {
    String sub = lyric.isEmpty() ? artist : lyric;
    long cur = playing ? pos + (SystemClock.elapsedRealtime() - stamp) : pos;
    MediaMetadataCompat.Builder mb = new MediaMetadataCompat.Builder()
        .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
        .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, sub)
        .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, dur);
    if (art != null) mb.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, art);
    ms.setMetadata(mb.build());
    long acts = PlaybackStateCompat.ACTION_PLAY | PlaybackStateCompat.ACTION_PAUSE | PlaybackStateCompat.ACTION_PLAY_PAUSE
        | PlaybackStateCompat.ACTION_SKIP_TO_NEXT | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS | PlaybackStateCompat.ACTION_SEEK_TO;
    ms.setPlaybackState(new PlaybackStateCompat.Builder().setActions(acts)
        .setState(playing ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED, cur, playing ? 1f : 0f).build());
    Intent li = launch();
    NotificationCompat.Builder b = new NotificationCompat.Builder(this, "vz")
        .setSmallIcon(android.R.drawable.ic_media_play)
        .setContentTitle(title.isEmpty() ? "Vanzz Stream" : title)
        .setContentText(sub)
        .setLargeIcon(art)
        .setOngoing(playing)
        .setOnlyAlertOnce(true)
        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        .addAction(android.R.drawable.ic_media_previous, "Sebelumnya", act("prev", 1))
        .addAction(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play, "Putar/Jeda", act(playing ? "pause" : "play", 2))
        .addAction(android.R.drawable.ic_media_next, "Berikutnya", act("next", 3))
        .setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
            .setMediaSession(ms.getSessionToken()).setShowActionsInCompactView(0, 1, 2));
    if (li != null) b.setContentIntent(PendingIntent.getActivity(this, 0, li, PendingIntent.FLAG_IMMUTABLE));
    Notification n = b.build();
    if (!fg) {
      fg = true;
      if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
      else startForeground(1, n);
    } else {
      nm.notify(1, n);
    }
    pill();
  }

  private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

  private void removePill() {
    if (pill != null && wm != null) { try { wm.removeView(pill); } catch (Exception e) { } }
    pill = null;
  }

  private void pill() {
    boolean ok = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    boolean want = VanzzPlayerPlugin.ovOn(this) && bg && playing && ok;
    if (!want) { removePill(); return; }
    if (pill == null) {
      wm = (WindowManager) getSystemService(WINDOW_SERVICE);
      pill = new LinearLayout(this);
      pill.setOrientation(LinearLayout.VERTICAL);
      pill.setGravity(Gravity.CENTER_HORIZONTAL);
      pill.setPadding(dp(20), dp(10), dp(20), dp(12));
      GradientDrawable g = new GradientDrawable();
      g.setColor(0xF2000000);
      g.setCornerRadius(dp(28));
      pill.setBackground(g);
      pt = new TextView(this);
      pt.setTextColor(0xFFAAAAAA);
      pt.setTextSize(11);
      pt.setSingleLine(true);
      pt.setEllipsize(TextUtils.TruncateAt.END);
      pt.setMaxWidth(dp(300));
      pl = new TextView(this);
      pl.setTextColor(0xFFFFFFFF);
      pl.setTextSize(15);
      pl.setMaxLines(2);
      pl.setGravity(Gravity.CENTER);
      pl.setEllipsize(TextUtils.TruncateAt.END);
      pl.setMaxWidth(dp(300));
      pill.addView(pt);
      pill.addView(pl);
      pill.setOnClickListener(v -> { Intent li = launch(); if (li != null) startActivity(li); });
      WindowManager.LayoutParams p = new WindowManager.LayoutParams(
          WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
          Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
          WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
          PixelFormat.TRANSLUCENT);
      p.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
      p.y = dp(36);
      try {
        pill.setAlpha(0f);
        wm.addView(pill, p);
        pill.animate().alpha(1f).setDuration(350).start();
      } catch (Exception e) { pill = null; return; }
    }
    pt.setText(title);
    pl.setText(lyric.isEmpty() ? artist : lyric);
  }

  @Override public void onTaskRemoved(Intent rootIntent) { kill(); }

  @Override public void onDestroy() {
    removePill();
    try { ms.release(); } catch (Exception e) { }
    inst = null;
    super.onDestroy();
  }

  @Override public IBinder onBind(Intent i) { return null; }
}
