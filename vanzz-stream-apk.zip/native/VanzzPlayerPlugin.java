package com.vanzz.stream;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "VanzzPlayer")
public class VanzzPlayerPlugin extends Plugin {
  static VanzzPlayerPlugin inst;

  static boolean ovOn(Context c) { return c.getSharedPreferences("vz", 0).getBoolean("ov", false); }

  @Override public void load() {
    inst = this;
    if (Build.VERSION.SDK_INT >= 33 && getActivity() != null) {
      ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.POST_NOTIFICATIONS}, 77);
    }
  }

  static void emit(String a, double pos) {
    if (inst == null) return;
    JSObject o = new JSObject();
    o.put("a", a);
    o.put("pos", pos);
    inst.notifyListeners("action", o);
  }

  @PluginMethod public void update(PluginCall c) {
    String t = c.getString("title", ""), a = c.getString("artist", ""), u = c.getString("art", "");
    boolean p = Boolean.TRUE.equals(c.getBoolean("playing", false));
    Double dp = c.getDouble("pos", 0.0), dd = c.getDouble("dur", 0.0);
    long pos = (long) ((dp == null ? 0 : dp) * 1000), dur = (long) ((dd == null ? 0 : dd) * 1000);
    MediaService s = MediaService.inst;
    if (s != null) {
      s.apply(t, a, u, p, pos, dur);
    } else if (p) {
      try {
        Intent i = new Intent(getContext(), MediaService.class);
        i.putExtra("t", t); i.putExtra("a", a); i.putExtra("u", u);
        i.putExtra("p", p); i.putExtra("pos", pos); i.putExtra("dur", dur);
        ContextCompat.startForegroundService(getContext(), i);
      } catch (Exception e) { }
    }
    c.resolve();
  }

  @PluginMethod public void lyric(PluginCall c) {
    MediaService s = MediaService.inst;
    if (s != null) s.setLyric(c.getString("line", ""));
    c.resolve();
  }

  @PluginMethod public void state(PluginCall c) {
    JSObject r = new JSObject();
    r.put("overlay", ovOn(getContext()));
    c.resolve(r);
  }

  @PluginMethod public void stop(PluginCall c) {
    if (MediaService.inst != null) MediaService.inst.kill();
    c.resolve();
  }

  @PluginMethod public void overlay(PluginCall c) {
    boolean en = Boolean.TRUE.equals(c.getBoolean("enabled", false));
    JSObject r = new JSObject();
    if (en && Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(getContext())) {
      Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getContext().getPackageName()));
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      getContext().startActivity(i);
      r.put("enabled", false);
      r.put("needPerm", true);
      c.resolve(r);
      return;
    }
    getContext().getSharedPreferences("vz", 0).edit().putBoolean("ov", en).apply();
    if (MediaService.inst != null) MediaService.inst.refresh();
    r.put("enabled", en);
    c.resolve(r);
  }

  @Override protected void handleOnPause() {
    MediaService.bg = true;
    if (MediaService.inst != null) MediaService.inst.refresh();
  }

  @Override protected void handleOnResume() {
    MediaService.bg = false;
    if (MediaService.inst != null) MediaService.inst.refresh();
  }
}
