import os, shutil, glob
from PIL import Image

A = "android"
jd = f"{A}/app/src/main/java/com/vanzz/stream"
os.makedirs(jd, exist_ok=True)
for f in glob.glob("native/*.java"):
    shutil.copy(f, jd)

mp = f"{A}/app/src/main/AndroidManifest.xml"
m = open(mp, encoding="utf8").read()
perms = "".join(f'    <uses-permission android:name="android.permission.{p}" />\n' for p in
                ["FOREGROUND_SERVICE", "FOREGROUND_SERVICE_MEDIA_PLAYBACK", "POST_NOTIFICATIONS", "SYSTEM_ALERT_WINDOW", "WAKE_LOCK"])
m = m.replace("<application", perms + "    <application", 1)
m = m.replace("</application>", '    <service android:name=".MediaService" android:exported="false" android:foregroundServiceType="mediaPlayback" />\n    </application>', 1)
open(mp, "w", encoding="utf8").write(m)

gp = f"{A}/app/build.gradle"
g = open(gp, encoding="utf8").read()
g = g.replace("dependencies {", "dependencies {\n    implementation 'androidx.media:media:1.7.0'", 1)
open(gp, "w", encoding="utf8").write(g)

shutil.rmtree(f"{A}/app/src/main/res/mipmap-anydpi-v26", ignore_errors=True)
im = Image.open("native/icon.png").convert("RGBA")
for d, s in {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}.items():
    p = f"{A}/app/src/main/res/mipmap-{d}"
    os.makedirs(p, exist_ok=True)
    r = im.resize((s, s), Image.LANCZOS)
    for n in ("ic_launcher.png", "ic_launcher_round.png"):
        r.save(f"{p}/{n}")
print("patch ok")
